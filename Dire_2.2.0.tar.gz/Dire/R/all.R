setOldClass("mmlCompositeMeans")
setOldClass("mmlMeans")
