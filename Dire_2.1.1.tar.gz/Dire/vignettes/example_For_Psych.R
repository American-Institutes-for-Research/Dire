t19_all <- readTIMSS("~/TIMSS/2019/", countries="*", grade=8) 

t19_usa <- readTIMSS("~/TIMSS/2019/", countries="usa", grade=8) 
t19_aus <- readTIMSS("~/TIMSS/2019/", countries="aus", grade=8) 

mml_o <- mml.sdf(mmat ~ itsex + bsbg03 + bsbg04 + bsbg05a + bsbg05b + bsbg05c + bsbg05d + bsbg05e + bsbg06a + bsbg06b, data=t19_aus, composite=FALSE)
mml_o <- mml.sdf(mmat ~ itsex + bsbg03 + bsbg04 + bsbg05a + bsbg05b + bsbg05c + bsbg05d + bsbg05e + bsbg06a + bsbg06b, data=t19_usa, composite=FALSE)

countries <- t19_all$covs$country
#countries <- rev(c("usa", "cot", "cqu", "rmo", "zgt", "zwc", "aad", "adu"))

# no student item data: "zgt", "zwc"
#countries <- c("zgt", "rmo", "cot", "usa", "aad", "adu", "cqu")
#countries <- c("alb", "rmo", "cot", "usa", "aad", "adu", "cqu")
n <- length(countries)
res <- data.frame(country=countries,
                  mean_comp=rep(NA, n),
                  mean_se_comp=rep(NA, n),
                  mean_over=rep(NA, n),
                  mean_se_over=rep(NA, n),
                  cor_comp=rep(NA, n),
                  cor_se_comp=rep(NA, n),
                  cor_over=rep(NA, n),
                  cor_se_over=rep(NA, n),
                  itsexgap_comp=rep(NA, n),
                  itsexgap_se_comp=rep(NA, n),
                  itsexgap_over=rep(NA, n),
                  itsexgap_se_over=rep(NA, n))

mml_c_list <- list()
mml_o_list <- list()
for(ci in 1:length(countries)) {
  #t19 <- readTIMSS("~/TIMSS/2019/", countries=countries[ci], grade=8) 
  t19 <- t19_all$datalist[[ci]]

  fix <- function(x, var) {
  x[x[,var] %in% "Algebra", var] <- "malg"
  x[x[,var] %in% "Geometry", var] <- "mgeo"
  x[x[,var] %in% "Data and Probability", var] <- "mdat"
  return(x)
  }
  dichotPT <- fix(getAttributes(t19, "dichotParamTab"), "content_subtest")
  polyPT <- fix(getAttributes(t19, "polyParamTab"), "content_subtest")
  testData <- fix(getAttributes(t19, "testData"), "subtest")

  t19 <- setAttributes(t19, "testData", testData)
  t19 <- setAttributes(t19, "dichotParamTab", dichotPT)
  t19 <- setAttributes(t19, "polyParamTab", polyPT)

  content_areas <- c("mnum","malg","mgeo","mdat")

  compositeTestData <- within(testData, {
    subtestWeight[subtest %in% content_areas] <- c(0.3,0.2,0.3,0.2)
  }) 
  t19comp <- t19
  t19comp <- setAttributes(t19, "testData", compositeTestData)

  # non-composite
  tic()
  mml_o <- tryCatch(mml.sdf(mmat ~ itsex + bsbg03 + bsbg04 + bsbg05a + bsbg05b + bsbg05c + bsbg05d + bsbg05e + bsbg06a + bsbg06b, data=t19, composite=FALSE), error=function(e) { print(e) })
  if(!inherits(mml_o, "error")){
    mml_dat <- mml.sdf(mdat ~ itsex + bsbg03 + bsbg04 + bsbg05a + bsbg05b + bsbg05c + bsbg05d + bsbg05e + bsbg06a + bsbg06b, data=t19, composite=FALSE)
    mml_alg <- mml.sdf(malg ~ itsex + bsbg03 + bsbg04 + bsbg05a + bsbg05b + bsbg05c + bsbg05d + bsbg05e + bsbg06a + bsbg06b, data=t19, composite=FALSE)
    toc()

    tic()
    mml_c <- mml.sdf(mmat ~ itsex + bsbg03 + bsbg04 + bsbg05a + bsbg05b + bsbg05c + bsbg05d + bsbg05e + bsbg06a + bsbg06b, data=t19comp, composite=TRUE)
    toc()

    # draw non-composite PVs
    tic()
    t19_o <- drawPVs(summary(mml_o), npv=5, stochasticBeta=TRUE, data=t19)
    t19_o <- drawPVs(summary(mml_dat), npv=5, stochasticBeta=TRUE, data=t19_o)
    t19_o <- drawPVs(summary(mml_alg), npv=5, stochasticBeta=TRUE, data=t19_o)
    toc()

    # draw composite PVs
    tic()
    t19_c <- drawPVs(summary(mml_c), npv=5, stochasticBeta=TRUE, data=t19comp)
    toc()


    lmo <- lm.sdf(mmat_dire ~ 1, data=t19_o)
    lmc <- lm.sdf(mmat_dire ~ 1, data=t19_c)
    res[ci,c("mean_comp", "mean_se_comp")] <- summary(lmc)$coefmat[1,c("coef","se")]
    res[ci,c("mean_over", "mean_se_over")] <- summary(lmo)$coefmat[1,c("coef","se")]

    #cor.sdf("malg", "mdat", data=t19_c)
    res[ci,c("cor_comp", "cor_se_comp")] <- cor.sdf("malg_dire", "mdat_dire", data=t19_c)[c("correlation", "se")]
    res[ci,c("cor_over", "cor_se_over")] <- cor.sdf("malg_dire", "mdat_dire", data=t19_o)[c("correlation", "se")]


    lmo_itsex <- lm.sdf(mmat_dire ~ itsex, data=t19_o)
    lmc_itsex <- lm.sdf(mmat_dire ~ itsex, data=t19_c)

    res[ci,c("itsexgap_comp", "itsexgap_se_comp")] <- summary(lmc_itsex)$coefmat[2,c("coef","se")]
    res[ci,c("itsexgap_over", "itsexgap_se_over")] <- summary(lmo_itsex)$coefmat[2,c("coef","se")]
    mml_c_list <- c(mml_c_list, list(mml_c))
    mml_o_list <- c(mml_o_list, list(mml_o))
    print(res)
  } else {
    print("No valid data for students, skipping.")
    toc()
  }
}
